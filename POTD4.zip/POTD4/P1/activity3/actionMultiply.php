<!-- bjk3yf Bryan Kim -->

Hello <?php echo htmlspecialchars($_POST['name']); ?>, 
You typed the values <?php echo (int)$_POST['val1']; ?> and <?php echo (int)$_POST['val2']; ?>.
Multiplied together, the value is 
<?php
 $x = (int)$_POST['val1'];
 $y = (int)$_POST['val2'];
 $z = $x * $y;
 echo $z . ".";
 ?>