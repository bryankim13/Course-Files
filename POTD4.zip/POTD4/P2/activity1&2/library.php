<!-- bjk3yf Bryan Kim -->

<?php
$SERVER = "usersrv01.cs.virginia.edu";
$USERNAME = "bjk3yf";
$PASSWORD = "REDACTED";
$DATABASE = "bjk3yf";
?>