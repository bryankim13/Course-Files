<!-- bjk3yf Bryan Kim -->
<?php
        require "dbutil.php";
        $db = DbUtil::loginConnection();

        $stmt = $db->stmt_init();

        if($stmt->prepare("select * from Sailors where sname like ?") or die(mysqli_error($db))) {
                $searchString = '%' . $_GET['searchLastName'] . '%';
                $stmt->bind_param(s, $searchString);
                $stmt->execute();
                $stmt->bind_result($sid, $sname, $rating, $age);
                echo "<table border=1><th>ID</th><th>Name</th><th>Rating</th><th>Age</th>\n";
                while($stmt->fetch()) {
                        echo "<tr><td>$sid</td><td>$sname</td><td>$rating</td><td>$age</td></tr>";
                }
                echo "</table>";

                $stmt->close();
        }

        $db->close();


?>